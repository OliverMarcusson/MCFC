bossbar remove debug_function_log:log_probe
bossbar add debug_function_log:log_probe {"text":"MCFC bossbar load probe 7D4C"}
bossbar set debug_function_log:log_probe max 1
bossbar set debug_function_log:log_probe value 1
